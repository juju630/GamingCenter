﻿using BusinessLayer.Command;
using BusinessLayer.Query;
using ClassLibrary.Entity;
using ClassLibrary.Mapping;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BusinessLayer
{
    public class Manager
    {
        private ContexteFluent _contexte;
        private static Manager _instance;

        private Manager()
        {
            _contexte = new ContexteFluent();

        }

        public static Manager GetInstance()
        {
            if(_instance == null)
            {
                _instance = new Manager();
            }
            return _instance;
        }

        public List<Jeu> GetAllJeux()
        {
            return new JeuQuery(_contexte).GetAllJeux();
        }

        public Jeu GetJeu(int id)
        {
            return new JeuQuery(_contexte).GetJeu(id);
        }

        public Jeu DeleteJeu(int id)
        {
            return new JeuCommand(_contexte).DeleteJeu(id);
        }

        public Jeu CreateJeu(string nom)
        {
            return new JeuCommand(_contexte).CreateJeu(nom); ;
        }

        public Jeu UpdateJeu(int id, string nom)
        {
            return new JeuCommand(_contexte).UpdateJeu(id, nom);
        }

    }
}
