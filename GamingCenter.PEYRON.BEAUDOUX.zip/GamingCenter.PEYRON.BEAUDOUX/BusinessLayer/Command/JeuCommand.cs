﻿using BusinessLayer.Query;
using ClassLibrary.Entity;
using ClassLibrary.Mapping;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BusinessLayer.Command
{
    class JeuCommand
    {
        private ContexteFluent _contexte = null;

        public JeuCommand(ContexteFluent contexte)
        {
            this._contexte = contexte;
        }

        public Jeu CreateJeu(string nom)
        {
            return _contexte.Jeux.Add(new Jeu { Nom = nom });
        }

        public Jeu DeleteJeu(int id)
        {
            Jeu tmp = new JeuQuery(_contexte).GetJeu(id);
            if(tmp != null)
            {
                return _contexte.Jeux.Remove(tmp);
            }
            return null;
        }

        public Jeu UpdateJeu(int id,string nom)
        {
            List<Jeu> listJeu = new JeuQuery(_contexte).GetAllJeux();
            Jeu tmp = new JeuQuery(_contexte).GetJeu(id);
            if(tmp != null)
            {
                tmp.Nom = nom;
                return _contexte.Jeux.Add(tmp);
            }
            return null;
        }
    }
}
