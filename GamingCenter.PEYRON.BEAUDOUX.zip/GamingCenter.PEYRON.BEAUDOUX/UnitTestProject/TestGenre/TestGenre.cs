﻿using ClassLibrary.Entity;
using ClassLibrary.Mapping;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UnitTestProject.TestGenre
{
    [TestClass]
    class TestGenre
    {

        [TestMethod]
        public void TestGenreCreation(string nom, bool expectedResult)
        {
            ContexteFluent contexte = new ContexteFluent();

            contexte.Genres.Add(new Genre { Nom = "jeu de chasse" });

            contexte.SaveChanges();

            List<Genre> genres = contexte.Genres.ToList();

            Assert.IsFalse(genres == null);
            Assert.Equals(genres.First().Nom,"jeu de chasse");
        }
    }
}
