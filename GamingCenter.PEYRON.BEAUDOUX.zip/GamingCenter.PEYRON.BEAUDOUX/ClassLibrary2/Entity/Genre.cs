﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ClassLibrary.Entity
{
    public class Genre
    {
        public int Id { get; set; }
        public string Nom { get; set; }
    }
}
